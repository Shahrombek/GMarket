import React from "react";
import { useRouter } from "next/router";
import { Typography } from "@mui/material";

export default function User(props) {
  const router = useRouter();

  console.log(router);

  const { nomer } = router.query;

  return <Typography variant="h3"> {nomer} </Typography>;
}
