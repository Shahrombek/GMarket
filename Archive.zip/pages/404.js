export default function Index() {
  return <div>Bunaqa sahifa mavjud emas</div>;
}
